"""Routines associated with the application data.
"""

courses = {}

import json
def load_data():
    """Load the data from the json file.
    """
    filedata=open("json\course.json",)
    jsondata=json.load(filedata)
    data=[]

    for i in jsondata:
        d={}
        d["id"]=i["id"]
        d["date_created"]=i["date_created"]
        d["date_updated"]=i["date_updated"]
        d["description"]=i["description"]
        d["discount_price"]=i["discount_price"]
        d["image_path"]=i["image_path"]
        d["on_discount"]=i["on_discount"]
        d["price"]=i["price"]
        d["title"]=i["title"]
        data.append(d)
    course={"message":data}
    return course

    file.close()
