"""Routes for the course resource.
"""

from run import app
from flask import request,jsonify
from http import HTTPStatus
import json
import data


@app.route("/course/<int:id>", methods=['GET'])
def get_course(id):
    """Get a course by id.

    :param int id: The record id.
    :return: A single course (see the challenge notes for examples)
    :rtype: object
    """

    """
    -------------------------------------------------------------------------
    Challenge notes:
    -------------------------------------------------------------------------
    1. Bonus points for not using a linear scan on your data structure.
    """
    # YOUR CODE HERE
    try:

         coursedata=data.load_data()
         flag=False
         courseData=[]
         for i in coursedata["message"]:
             dict={}
             if i["id"]==int(id):
                 flag=True
                 dict["id"]=i["id"]
                 dict["date_created"]=i["date_created"]
                 dict["date_updated"]=i["date_updated"]
                 dict["description"]=i["description"]
                 dict["discount_price"]=i["discount_price"]
                 dict["image_path"]=i["image_path"]
                 dict["on_discount"]=i["on_discount"]
                 dict["price"]=i["price"]
                 dict["title"]=i["title"]
                 courseData.append(dict)
         if flag:
            return jsonify({'data':courseData}),200
         return jsonify({'message':'id does not exist'}),400
    except Exception as e:
          print(e)
          return jsonify({'message':'something wrong'}),500


@app.route("/course", methods=['GET'])
def get_courses():
    """Get a page of courses, optionally filtered by title words (a list of
    words separated by commas".

    Query parameters: page-number, page-size, title-words
    If not present, we use defaults of page-number=1, page-size=10

    :return: A page of courses (see the challenge notes for examples)
    :rtype: object
    """

    """
    -------------------------------------------------------------------------
    Challenge notes:
    -------------------------------------------------------------------------
    1. Bonus points for not using a linear scan, on your data structure, if
       title-words is supplied
    2. Bonus points for returning resulted sorted by the number of words which
       matched, if title-words is supplied.
    3. Bonus points for including performance data on the API, in terms of
       requests/second.
    """
    # YOUR CODE HERE
    try:
        #import pdb; pdb.set_trace()
        coursedata=data.load_data()
        return jsonify(coursedata),201
    except Exception as e:
        print(e)
        return jsonify({'message':'some something gone wrong'}),500


@app.route("/course", methods=['POST'])
def create_course():
    """Create a course.
    :return: The course object (see the challenge notes for examples)
    :rtype: object
    """

    """
    -------------------------------------------------------------------------
    Challenge notes:
    -------------------------------------------------------------------------
    1. Bonus points for validating the POST body fields
    """
    # YOUR CODE HERE
    try:
        i=request.get_json()
        coursedata=data.load_data()
        arr=[]
        id=200
        dict={}
        id+=1
        dict["id"]=id
        dict["date_created"]=i["date_created"]
        dict["date_updated"]=i["date_updated"]
        dict["description"]=i["description"]
        dict["discount_price"]=i["discount_price"]
        dict["image_path"]=i["image_path"]
        dict["on_discount"]=i["on_discount"]
        dict["price"]=i["price"]
        dict["title"]=i["title"]
        arr.append(dict)
        id+=1
        update_course_data=coursedata["message"]+arr
        return jsonify({"data":"successfully new course is Created","length":len(update_course_data)}),200
    except Exception as e:
        print(e)
        return jsonify({"message":"new course is not Created"}),500


@app.route("/course/<int:id>", methods=['PUT'])
def update_course(id):
    """Update a a course.
    :param int id: The record id.
    :return: The updated course object (see the challenge notes for examples)
    :rtype: object
    """

    """
    -------------------------------------------------------------------------
    Challenge notes:
    -------------------------------------------------------------------------
    1. Bonus points for validating the PUT body fields, including checking
       against the id in the URL

    """
    # YOUR CODE HERE
    try:
        coursedata=data.load_data()
        course_details=request.get_json()
        flag=False
        for i in coursedata["message"]:
            if i["id"]==int(id):
                flag=True
                i["id"]=id
                i["date_created"]=course_details["date_created"]
                i["date_updated"]=course_details["date_updated"]
                i["description"]=course_details["description"]
                i["discount_price"]=course_details["discount_price"]
                i["image_path"]=course_details["image_path"]
                i["on_discount"]=course_details["on_discount"]
                i["price"]=course_details["price"]
                i["title"]=course_details["title"]
        if flag:
            return jsonify({"message":"successfully update course"}),201
        return jsonify({"message":"id does not exit"}),400
    except Exception as e:
        print(e)
        return jsonify({"message":"some worng, course not update"}),500


@app.route("/course/<int:id>", methods=['DELETE'])
def delete_course(id):
    """Delete a course
    :return: A confirmation message (see the challenge notes for examples)
    """
    """
    -------------------------------------------------------------------------
    Challenge notes:
    -------------------------------------------------------------------------
    None
    """
    # YOUR CODE HERE
    try:
        coursedata=data.load_data()
        flag=False
        for i in coursedata['message']:
            if i["id"]==int(id):
                flag=True
                coursedata['message'].remove(i)

        if flag:
            coursedata=coursedata['message']
            return jsonify({"message":"successfully course is deleted course","left_data":len(coursedata)}),201
        return jsonify({"message":"id does not exit"}),400

    except Exception as e:
        print(e)
        return jsonify({"message":"id is not delete"}),500
